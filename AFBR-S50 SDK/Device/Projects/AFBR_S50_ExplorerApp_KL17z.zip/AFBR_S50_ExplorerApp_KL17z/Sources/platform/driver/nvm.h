/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 API.
 * @details		This file contains implementations of the non-volatile memory module.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef NVM_H
#define NVM_H

/*!***************************************************************************
 * @defgroup	nvm Non-Volatile Memory Module
 * @ingroup		dirver
 * @brief		Non-Volatile Memory Module
 * @details		An application specific wrapper around the flash module to
 * 				save/load the application specific settings.
 *
 * @addtogroup 	nvm
 * @{
 *****************************************************************************/

/*******************************************************************************
 * Include Files
 ******************************************************************************/

#include "platform/argus_nvm.h"

/*!*****************************************************************************
 * @brief	Clears the NVM memory with zeros.
 * @return 	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t NVM_Clear(void);

/*! @} */
#endif /* NVM_H */
