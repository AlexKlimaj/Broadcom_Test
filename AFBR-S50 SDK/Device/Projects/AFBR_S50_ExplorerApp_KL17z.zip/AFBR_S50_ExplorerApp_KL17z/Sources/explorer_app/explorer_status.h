/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer example application.
 * @details		This file provides status definitions.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef EXPLORER_STATUS_H
#define EXPLORER_STATUS_H

/*!***************************************************************************
 * @defgroup	status Status Codes
 * @brief		Status Codes Definitions
 * @details		Defines status codes for specific functions.
 * @addtogroup 	status
 * @{
 *****************************************************************************/

#include "utility/status.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

///*! @brief AFBR-S50 Explorer App status and error return codes.
// *  @ingroup status */
//enum StatusExplorer
//{
//	STATUS_EXPLORER_?		= 201,
//};

/*! @} */
#endif /* EXPLORER_STATUS_H */
