/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer Demo Application.
 * @details		This file contains current Explorer Application version number.
 *
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef EXPLORER_VERSION_H
#define EXPLORER_VERSION_H

/*!***************************************************************************
 * @defgroup	version Version
 * @ingroup		explorerapp
 * @brief		Explorer Application Code Version.
 * @details		Provides a version number for Explorer Application.
 * @addtogroup 	version
 * @{
 *****************************************************************************/

/*! @brief Major version number of the platform code. */
#define EXPLORER_VERSION_MAJOR    1

/*! @brief Minor version number of the platform code. */
#define EXPLORER_VERSION_MINOR    2

/*! @brief Bugfix version number of the platform code. */
#define EXPLORER_VERSION_BUGFIX   3

/*! Build version nunber of the AFBR-S50 API. */
#define EXPLORER_VERSION_BUILD    "20201120091253"

/*****************************************************************************/

/*! @brief Construct the version number for drivers. */
#define MAKE_VERSION(major, minor, bugfix) \
	(((major) << 24) | ((minor) << 16) | (bugfix))

/*! @brief the current version of the platform code. */
#define EXPLORER_VERSION MAKE_VERSION((EXPLORER_VERSION_MAJOR), \
									  (EXPLORER_VERSION_MINOR), \
									  (EXPLORER_VERSION_BUGFIX))

/*! @} */
#endif /* EXPLORER_VERSION_H */
