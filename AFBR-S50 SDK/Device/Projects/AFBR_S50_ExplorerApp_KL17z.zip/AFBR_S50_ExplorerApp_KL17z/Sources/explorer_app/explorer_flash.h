/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer Demo Application.
 * @details		This file contains the main functionality of the Explorer Application.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef EXPLORER_FLASH_H
#define EXPLORER_FLASH_H

/*!***************************************************************************
 * @defgroup	explorerflash AFBR-S50 Explorer Flash Module
 * @ingroup		explorermain
 * @brief		AFBR-S50 Explorer Flash Module
 * @details		An application specific wrapper around the flash module to
 * 				save/load the application specific settings.
 *
 * @addtogroup 	explorerflash
 * @{
 *****************************************************************************/

#include "explorer_status.h"
#include "api/explorer_api.h"


/*!***************************************************************************
 * @brief	Loads the configuration from the flash memory.
 * @details
 * @param	argus The Argus device handle.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t ExplorerApp_LoadCfgFromFlash(argus_hnd_t * argus);

/*!***************************************************************************
 * @brief	Loads the calibration from the flash memory.
 * @details
 * @param	argus The Argus device handle.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t ExplorerApp_LoadCalFromFlash(argus_hnd_t * argus);

/*!***************************************************************************
 * @brief	Saves the configuration to the flash memory.
 * @details
 * @param	argus The Argus device handle.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t ExplorerApp_SaveCfgToFlash(argus_hnd_t * argus);

/*!***************************************************************************
 * @brief	Saves the calibration to the flash memory.
 * @details
 * @param	argus The Argus device handle.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t ExplorerApp_SaveCalToFlash(argus_hnd_t * argus);

/*!***************************************************************************
 * @brief	Deletes the configuration from the flash memory.
 * @details
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t ExplorerApp_ClearCfgFromFlash(void);

/*!***************************************************************************
 * @brief	Deletes the calibration from the flash memory.
 * @details
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t ExplorerApp_ClearCalFromFlash(void);

/*!***************************************************************************
 * @brief	Deletes the all application specific values from memory.
 * @details
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t ExplorerApp_ClearFlash(void);

/*! @} */
#endif /* EXPLORER_FLASH_H */
