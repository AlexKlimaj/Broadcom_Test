/*************************************************************************//**
 * @file
 * @brief    	SCI Layer 3: Command (Message) Interface
 * @details		This file provides an interface for the command or message layer
 *				of the systems communication interface.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef SCI_CMD_H
#define SCI_CMD_H

/*!***************************************************************************
 * @defgroup	sci_cmd SCI: Generic Command Definitions
 * @ingroup		sci
 * @brief		Generic Command Definitions
 * @details		Generic command definitions for the systems communication interface.
 * @addtogroup 	sci_cmd
 * @{
 *****************************************************************************/

#include "sci_status.h"

/*! Determines whether to include a time stamp into log messages. */
#define SCI_LOG_TIMESTAMP 1


/*! Generic commands for the SCI module. */
enum GenericSerialCommandCodes
{
	CMD_INVALID				= 0x00, /*!< Program internal marker for invalid/erroneous commands. */

	/* Generic commands. */
	CMD_LOG_MESSAGE 		= 0x06, /*!< An event/debug log message. */
	CMD_STATUS_REPORT		= 0x07, /*!< Software status/error report (running, pause, error, ...) from MCU or request from PC. */
	CMD_ACKNOWLEDGE 		= 0x0A, /*!< Acknowledge of the previous command. */
	CMD_NOT_ACKNOWLEDGE		= 0x0B, /*!< Not-acknowledge of the previous command. */
	CMD_SYSTEM_RESET 		= 0x08, /*!< Command to reset the MCU. */
	CMD_BOOTLOADER			= 0x09, /*!< Enters the bootloader mode. */

	/* Misc. commands. */
	CMD_TEST_MESSAGE		= 0x04, /*!< Test message send to the slave. The slave will reflect the message back to the master. */

};

/*!***************************************************************************
 * @brief	Sends an status report.
 * @param	statusThe status value to be reported.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t SCI_SendStatusReport(status_t status);

/*!***************************************************************************
 * @brief	Sends a log message.
 * @param	fmt_s The printf() format string.
 * @param	...   The printf() arguments.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t SCI_SendLogEntry(const char *fmt_s, ...);

/*!***************************************************************************
 * @brief	Sends a log message.
 * @param	fmt_s The printf() format string.
 * @param	...   The printf() arguments.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t SCI_Printf(const char  *fmt_s, ...);

/*!***************************************************************************
 * @brief	Sends a log message.
 * @param	fmt_s The printf() format string.
 * @param	...   The printf() arguments.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t print(const char  *fmt_s, ...);


/*! @} */
#endif /* SCI_CMD_H */
