/*************************************************************************//**
 * @file
 * @brief    	SCI Handshaking Commands
 * @details		This file provides an interface for the data link layer of the
 *				systems communication interface.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

/*******************************************************************************
 * Include Files
 ******************************************************************************/
#include "sci_handshaking.h"
#include "sci_datalink.h"
#include "sci_cmd.h"

#include <stdbool.h>

/*******************************************************************************
 * Definitions
 ******************************************************************************/


/*******************************************************************************
 * Prototypes
 ******************************************************************************/


/******************************************************************************
 * Variables
 ******************************************************************************/


/*******************************************************************************
 * Code
 ******************************************************************************/

status_t SCI_SendAcknowledge(sci_cmd_t cmd)
{
	sci_frame_t * frame = SCI_DataLink_RequestTxFrame(true);
	if(!frame) return ERROR_SCI_BUFFER_FULL;
	SCI_Frame_Queue08u(frame, CMD_ACKNOWLEDGE);
	SCI_Frame_Queue08u(frame, cmd);
	return SCI_DataLink_SendTxFrame(frame);
}

status_t SCI_SendNotAcknowledge(sci_cmd_t cmd, status_t reason)
{
	sci_frame_t * frame = SCI_DataLink_RequestTxFrame(true);
	if(!frame) return ERROR_SCI_BUFFER_FULL;
	SCI_Frame_Queue08u(frame, CMD_NOT_ACKNOWLEDGE);
	SCI_Frame_Queue08u(frame, cmd);
	SCI_Frame_Queue16s(frame, (int16_t)reason);
	return SCI_DataLink_SendTxFrame(frame);
}
