/*************************************************************************//**
 * @file
 * @brief    	SCI: Byte stuffing definitions.
 * @details		This file provides an interface for the systems communication
 * 				interface.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef SCI_BYTE_STUFFING_H
#define SCI_BYTE_STUFFING_H

/*!***************************************************************************
 * @defgroup	sci_bytestuffing SCI: Byte Stuffing
 * @ingroup		sci
 * @brief		SCI byte stuffing definitions.
 * @details		Byte stuffing definitions for systems communication interface.
 * @addtogroup 	sci_bytestuffing
 * @{
 *****************************************************************************/

#define SCI_START_BYTE  	(0x02) /*!< SCI: Start byte. */
#define SCI_STOP_BYTE   	(0x03) /*!< SCI: Stop byte. */
#define SCI_ESCAPE_BYTE 	(0x1B) /*!< SCI: Escape byte. */

/*! @} */
#endif /* SCI_BYTE_STUFFING_H */
