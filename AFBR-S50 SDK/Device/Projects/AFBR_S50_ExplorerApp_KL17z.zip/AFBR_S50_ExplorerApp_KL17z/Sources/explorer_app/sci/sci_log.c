/*************************************************************************//**
 * @file
 * @brief    	SCI: Command definitions for log messages in printf style.
 * @details		This file provides an implementation for log messages/commands
 * 				in the printf style of the C standard library that can be used
 * 				along with the systems communication interface.
 * @details		This file provides command definitions for the systems
 * 				communication interface.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/


/*******************************************************************************
 * Include Files
 ******************************************************************************/
#include "sci_cmd.h"
#include "sci_frame.h"

#include <stdarg.h>

#include "utility/debug_console.h"


/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*!***************************************************************************
 * @brief	A vprintf() function for the uart connection.
 * @details	This function is similar to #UART_Printf except that, instead of
 * 			taking a variable number of arguments directly, it takes an
 * 			argument list pointer ap. Requires a call to #va_start(ap, fmt_s);
 * 			before and va_end(ap); after this function.
 * @param	fmt_s The printf() format string.
 * @param	ap The argument list.
 * @return 	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
static inline status_t vprint(const char *fmt_s, va_list * ap);

/*! @cond */
#if SCI_LOG_TIMESTAMP
#include "utility/time.h"
#include "utility/fp_rnd.h"
void Time_GetNow(ltc_t * t_now) __attribute__((weak));
uint32_t Time_GetSec(ltc_t const * t) __attribute__((weak));
uint32_t Time_GetUSec(ltc_t const * t) __attribute__((weak));
#endif

extern status_t SCI_DataLink_SendTxFrame(sci_frame_t * frame);
extern sci_frame_t * SCI_DataLink_RequestTxFrame(bool queueStartByte);
/*! @endcond */

/******************************************************************************
 * Variables
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/



status_t SCI_SendLogEntry(const char *fmt_s, ...)
{
	va_list  ap;
	va_start(ap, fmt_s);
	status_t status = vprint(fmt_s, &ap);
	va_end(ap);
	return status;
}


status_t print(const char  *fmt_s, ...)
{
	va_list  ap;
	va_start(ap, fmt_s);
	status_t status = vprint(fmt_s, &ap);
	va_end(ap);
	return status;
}
static inline status_t vprint(const char *fmt_s, va_list * ap)
{
	/* sending a log message in formated printf style */

	sci_frame_t * frame = SCI_DataLink_RequestTxFrame(true);
	if(!frame) return ERROR_SCI_BUFFER_FULL;

	SCI_Frame_Queue08u(frame, CMD_LOG_MESSAGE);

#if SCI_LOG_TIMESTAMP
	ltc_t t_now;
	Time_GetNow(&t_now);
	SCI_Frame_Queue_Time(frame, &t_now);
#endif

    PrintfFormattedData(SCI_Frame_PutChar, frame, fmt_s, ap);

    return SCI_DataLink_SendTxFrame(frame);
}

/*! @cond */
#if SCI_LOG_TIMESTAMP
void Time_GetNow(ltc_t * t_now) { t_now->sec = 0; t_now->usec = 0; }
uint32_t Time_GetSec(ltc_t const * t) { (void)t;  return 0; }
uint32_t Time_GetUSec(ltc_t const * t) { (void)t; return 0; }
#endif
/*! @endcond */
