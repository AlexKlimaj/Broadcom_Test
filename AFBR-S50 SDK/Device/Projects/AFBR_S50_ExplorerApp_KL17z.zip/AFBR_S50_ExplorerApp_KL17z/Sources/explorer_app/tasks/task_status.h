/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer example application.
 * @details		This file provides status definitions.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef TASK_STATUS_H
#define TASK_STATUS_H

/*!***************************************************************************
 * @defgroup	status Status Codes
 * @brief		Status Codes Definitions
 * @details		Defines status codes for specific functions.
 * @addtogroup 	status
 * @{
 *****************************************************************************/

#include "utility/status.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*! @brief Task scheduler status and error return codes.
 *  @ingroup status */
enum StatusTask
{
	/*! Task has not finished and needs to be postponed. Lower priority tasks
	 *  are executed meanwhile. */
	STATUS_TASK_POSTPONE		= 231,

	/*! Task queue is full. Event not queued. */
	ERROR_TASK_QUEUE_FULL		= -231,
};


/*! @} */
#endif /* TASK_STATUS_H */
