/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer example application.
 * @details		A utility module that measures execution times of tasks.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/


/*******************************************************************************
 * Include Files
 ******************************************************************************/
#include "task_profiler.h"

#if PROFILING

#include "task_scheduler.h"

#include <assert.h>
#include <stdint.h>
#include "task_status.h"
#include "utility/debug.h"
#include "utility/time.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define LOG_COUNT 254

/*!***************************************************************************
 * @brief Task profiler information definition.
 *****************************************************************************/
typedef struct
{
	uint32_t ExecutionCount;
	uint32_t FailedExecutionCount;
	ltc_t ExecutionTime;
	ltc_t LastStartTimeStamp;
} taskprofileinfo_t;

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void OnTaskStart(uint32_t priority);
void OnTaskFinished(uint32_t priority, status_t status);
void OnTaskQueued(uint32_t priority);

static void ProfilerLog(char type, char id);

/******************************************************************************
 * Variables
 ******************************************************************************/
static taskprofileinfo_t myTPI[SCHEDULER_MAX_TASKS] = {{0}};
static char myLogStr[LOG_COUNT+2] = {0};
static char * myLogPtr = myLogStr;

/*******************************************************************************
 * Code
 ******************************************************************************/
static void ProfilerLog(char type, char id)
{
//	*(myLogPtr++) = type;
//	*(myLogPtr++) = id;
//	if(myLogPtr - myLogStr > LOG_COUNT)
//	{
//		print(myLogStr);
//		myLogPtr = myLogStr;
//	}
}

void OnTaskStart(uint32_t priority)
{
	ProfilerLog('S', (char)('a' + priority));
	Time_GetNow(&(myTPI[priority].LastStartTimeStamp));
}
void OnTaskFinished(uint32_t priority, status_t status)
{
	if(status == STATUS_OK)
	{
		ltc_t t = {0};
		Time_GetElapsed(&t, &(myTPI[priority].LastStartTimeStamp));
		Time_Add(&(myTPI[priority].ExecutionTime), &(myTPI[priority].ExecutionTime), &t);
		myTPI[priority].ExecutionCount++;
		ProfilerLog('P', (char)('a' + priority));
	}
	else
	{
		myTPI[priority].FailedExecutionCount++;
		ProfilerLog('F', (char)('a' + priority));
	}
}
void OnTaskQueued(uint32_t priority)
{
	ProfilerLog('Q', (char)('a' + priority));
	if(myLogPtr - myLogStr > LOG_COUNT)
	{
		print(myLogStr);
		myLogPtr = myLogStr;
	}
}



#endif /* PROFILING */
