/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer example application.
 * @details		A utility module that measures execution times of tasks.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef TASK_PROFILER_H
#define TASK_PROFILER_H

/*!***************************************************************************
 * @defgroup	profiler Task Profiler
 * @ingroup		task
 * @brief		A utility module that measures execution times of tasks.
 * @details		This module provides basic functionality to do a simple
 * 				profiling of the scheduler tasks.
 *
 * 				UNDER CONSTRUCTION!
 *
 * 				This module is under construction and experimental.
 * 				A function is called before and after executing a task. The
 * 				consumed time is measured and summed via the platform time.h
 * 				utility module. For now, a debugger breakpoint can be used to
 * 				read the data from the device...
 *
 *
 * @addtogroup 	profiler
 * @{
 *****************************************************************************/


/*!***************************************************************************
 * @brief	Enabled the profiler as preprocessor option.
 *****************************************************************************/
#define PROFILING 0


/*! @} */
#endif /* TASK_PROFILER_H */
