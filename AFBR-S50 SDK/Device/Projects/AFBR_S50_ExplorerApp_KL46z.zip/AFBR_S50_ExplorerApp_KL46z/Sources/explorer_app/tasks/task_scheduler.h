/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer example application.
 * @details		This file implements an simple task scheduler.
 * @warning 	Confidential under NDA!
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef TASK_SCHEDULER_H
#define TASK_SCHEDULER_H

/*!***************************************************************************
 * @defgroup	scheduler Task Scheduler
 * @ingroup		task
 * @brief		A simple cooperative task scheduler with prioritized tasks.
 * @details		A simple cooperative task scheduler with prioritized tasks.
 * @addtogroup 	scheduler
 * @{
 *****************************************************************************/


#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#include "task_status.h"

/*!***************************************************************************
 * @brief	Maximum Number of tasks.
 * @warning	Maximum number is 32 due to internal data structures of size uint32.
 * 			If larger number of tasks are desired, the internal data structures
 * 			need to be adjusted.
 *****************************************************************************/
#define SCHEDULER_MAX_TASKS 8U

/*!***************************************************************************
 * @brief	Task event definition.
 *****************************************************************************/
typedef void * task_event_t;

/*!***************************************************************************
 * @brief	Task functions definition.
 * @param	p Task event pointer. An abstract pointer to an task intern data
 * 				structure.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
typedef status_t (*task_function_t)(task_event_t p);

/*!***************************************************************************
 * @brief 	Initializes the task scheduler.
 * @details	Resets internal data structures to a known state.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
void Scheduler_Init(void);

/*!***************************************************************************
 * @brief	Runs the task scheduler.
 * @details	This is the main routine for the scheduler module. It schedules all
 * 			the pending tasks in order of priority in an endless loop.
 * 			If an error occurs within an task, the error is logged, but not
 * 			handled!
 * @return	This function never returns!
 *****************************************************************************/
void Scheduler_Run(void);

/*!***************************************************************************
 * @brief	Adds an new task to the scheduler.
 * @param	task       A pointer to the task function to be executed.
 * @param	priority   The priority level for the task. Every priority level
 * 						 can only have one task!
 * @param	eventQ     A pointer to the task event queue.
 * @param	eventQSize The size of the task event queue.
 * @param	name 	   A descriptive name of the task.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t Scheduler_AddTask(task_function_t task,
						   uint32_t priority,
						   task_event_t eventQ,
						   size_t eventQSize,
						   char * name);

/*!***************************************************************************
 * @brief	Posts an event to the scheduler and executes it as soon as possible
 * @param	priority The priority of the task to be executed.
 * @param	event    A void* pointer to and task event parameter.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t Scheduler_PostEvent(uint32_t priority, task_event_t event);

/*!***************************************************************************
 * @brief	Checks whether a specified task is pending for execution.
 * @param	priority The priority of the task to be checked.
 * @return	Returns true if the task is pending, false otherwise.
 *****************************************************************************/
bool Scheduler_IsTaskPending(uint32_t priority);

/*! @} */
#endif /* TASK_SCHEDULER_H */
