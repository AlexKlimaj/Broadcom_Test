/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer example application.
 * @details		This file contains the main function for the Explorer app.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#include "explorer_app.h"

/*!***************************************************************************
 * @brief	Application entry point.
 *
 * @details	The main function of the program, called after startup code
 * 			This function should never be exited.
 *****************************************************************************/
int main(void)
{
	ExplorerApp_Init();
	ExplorerApp_Run();
	return 0;
}

#ifdef DEBUG
#include <string.h>
void SystemInitHook (void)
{
	/* Reset the entire RAM memory after reset in order
	 * to investigate the memory usage while debugging. */
	memset((void*)0x1FFFE000U, 0xAAU, 0x7FE0U);
}
#endif
