/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer Demo Application.
 * @details		This file contains the main functionality of the Explorer Application.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

/*******************************************************************************
 * Include Files
 ******************************************************************************/
#include "explorer_flash.h"
