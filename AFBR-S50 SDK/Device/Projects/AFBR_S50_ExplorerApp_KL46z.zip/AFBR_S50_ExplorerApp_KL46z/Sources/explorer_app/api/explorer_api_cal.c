/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer Demo Application.
 * @details		This file contains the hardware API of the Explorer Application.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/


/*******************************************************************************
 * Include Files
 ******************************************************************************/
#include "explorer_api_cal.h"
#include "explorer_app.h"
#include "explorer_flash.h"

#include "argus.h"

#include <assert.h>

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/

/*! The Argus data structure for executing device specific commands. */
static argus_hnd_t * myArgusPtr;

/*******************************************************************************
 * Parsing Functions
 ******************************************************************************/

static void Serialize_Cal_P2PXtalk(sci_frame_t * frame, argus_cal_p2pxtalk_t const * cal)
{
	assert(frame != 0);
	assert(cal != 0);

	/* Pixel-To-Pixel Crosstalk */
	SCI_Frame_Queue16u(frame, cal->KcFactorS);
	SCI_Frame_Queue16u(frame, cal->KcFactorC);
	SCI_Frame_Queue16u(frame, cal->KcFactorSRefPx);
	SCI_Frame_Queue16u(frame, cal->KcFactorCRefPx);
	SCI_Frame_Queue08s(frame, cal->RelativeThreshold);
	SCI_Frame_Queue16u(frame, cal->AbsoluteTreshold);
}
static void Deserialize_Cal_P2PXtalk(sci_frame_t * frame, argus_cal_p2pxtalk_t * cal)
{
	assert(frame != 0);
	assert(cal != 0);

	/* Pixel-To-Pixel Crosstalk */
	cal->KcFactorS = SCI_Frame_Dequeue16s(frame);
	cal->KcFactorC = SCI_Frame_Dequeue16s(frame);
	cal->KcFactorSRefPx = SCI_Frame_Dequeue16s(frame);
	cal->KcFactorCRefPx = SCI_Frame_Dequeue16s(frame);
	cal->RelativeThreshold = SCI_Frame_Dequeue08u(frame);
	cal->AbsoluteTreshold = SCI_Frame_Dequeue16u(frame);
}


/*******************************************************************************
 * Command Functions
 ******************************************************************************/

static status_t RxCmd_CalGlobalRangeOffset(sci_frame_t * frame)
{
	if (SCI_Frame_BytesToRead(frame) > 1)
	{
		argus_mode_t mode = SCI_Frame_Dequeue08u(frame);
		if (SCI_Frame_BytesToRead(frame) > 1)
		{ /* Master sending data... */
			q9_22_t offset = SCI_Frame_Dequeue32s(frame);
			return Argus_SetCalibrationGlobalRangeOffset(myArgusPtr, mode, offset);
		}
		else
		{ /* Master is requesting data... */
			return SCI_SendCommand(CMD_CALIBRATION_GLOBAL_RANGE_OFFSET, mode, 0);
		}
	}
	else
	{
		return ERROR_SCI_FRAME_TOO_SHORT;
	}
}
static status_t TxCmd_CalGlobalRangeOffset(sci_frame_t * frame, sci_param_t param, sci_data_t data)
{
	(void) data;
	assert(frame != 0);
	status_t status = STATUS_OK;
	if (param == 0) return ERROR_SCI_INVALID_CMD_PARAMETER;
	argus_mode_t mode = (argus_mode_t) param;
	SCI_Frame_Queue08u(frame, mode);
	q9_22_t offset;
	status = Argus_GetCalibrationGlobalRangeOffset(myArgusPtr, mode, &offset);
	SCI_Frame_Queue32s(frame, offset);
	return status;
}

static status_t RxCmd_CalPixelRangeOffsets(sci_frame_t * frame)
{
	if (SCI_Frame_BytesToRead(frame) > 1)
	{
		argus_mode_t mode = SCI_Frame_Dequeue08u(frame);
		if (SCI_Frame_BytesToRead(frame) > 1)
		{ /* Master sending data... */
			q0_15_t offsets[ARGUS_PIXELS_X][ARGUS_PIXELS_Y];
			for (uint_fast8_t x = 0; x < ARGUS_PIXELS_X; ++x)
			{
				for (uint_fast8_t y = 0; y < ARGUS_PIXELS_Y; ++y)
				{
					offsets[x][y] = SCI_Frame_Dequeue16s(frame);
				}
			}
			return Argus_SetCalibrationPixelRangeOffsets(myArgusPtr, mode, offsets);
		}
		else
		{ /* Master is requesting data... */
			return SCI_SendCommand(CMD_CALIBRATION_PIXEL_RANGE_OFFSETS, mode, 0);
		}
	}
	else
	{
		return ERROR_SCI_FRAME_TOO_SHORT;
	}
}
static status_t TxCmd_CalPixelRangeOffsets(sci_frame_t * frame, sci_param_t param, sci_data_t data)
{
	(void) data;
	assert(frame != 0);
	status_t status = STATUS_OK;
	if (param == 0) return ERROR_SCI_INVALID_CMD_PARAMETER;
	argus_mode_t mode = (argus_mode_t) param;
	SCI_Frame_Queue08u(frame, mode);
	q0_15_t offsets[ARGUS_PIXELS_X][ARGUS_PIXELS_Y];
	status = Argus_GetCalibrationPixelRangeOffsets(myArgusPtr, mode, offsets);
	for (uint_fast8_t x = 0; x < ARGUS_PIXELS_X; ++x)
	{
		for (uint_fast8_t y = 0; y < ARGUS_PIXELS_Y; ++y)
		{
			SCI_Frame_Queue16s(frame, offsets[x][y]);
		}
	}
	return status;
}

static status_t RxCmd_CalResetPixelRangeOffsets(sci_frame_t * frame)
{
	argus_mode_t mode = SCI_Frame_Dequeue08u(frame);
	return Argus_ResetCalibrationPixelRangeOffsets(myArgusPtr, mode);
}

static status_t RxCmd_CalRangeOffsetSeqSampleCount(sci_frame_t * frame)
{
	if (SCI_Frame_BytesToRead(frame) > 1)
	{ /* Master sending data... */
		uint16_t count = SCI_Frame_Dequeue16u(frame);
		return Argus_SetCalibrationRangeOffsetSequenceSampleCount(myArgusPtr, count);
	}
	else
	{ /* Master is requesting data... */
		return SCI_SendCommand(CMD_CALIBRATION_RANGE_OFFSET_SAMPLE_COUNT, 0, 0);
	}
}
static status_t TxCmd_CalRangeOffsetSeqSampleCount(sci_frame_t * frame, sci_param_t param, sci_data_t data)
{
	(void) data;
	(void) param;
	assert(frame != 0);
	status_t status = STATUS_OK;
	uint16_t count;
	status = Argus_GetCalibrationRangeOffsetSequenceSampleCount(myArgusPtr, &count);
	SCI_Frame_Queue16u(frame, count);
	return status;
}

static status_t RxCmd_CalXtalkPixel2Pixel(sci_frame_t * frame)
{
	if (SCI_Frame_BytesToRead(frame) > 1)
	{
		argus_mode_t mode = SCI_Frame_Dequeue08u(frame);
		if (SCI_Frame_BytesToRead(frame) > 1)
		{ /* Master sending data... */
			argus_cal_p2pxtalk_t cal = { 0 };
			cal.Enabled = SCI_Frame_Dequeue08u(frame) != 0;
			Deserialize_Cal_P2PXtalk(frame, &cal);
			return Argus_SetCalibrationCrosstalkPixel2Pixel(myArgusPtr, mode, &cal);
		}
		else
		{ /* Master is requesting data... */
			return SCI_SendCommand(CMD_CALIBRATION_XTALK_PIXEL_2_PIXEL, mode, 0);
		}
	}
	else
	{
		return ERROR_SCI_FRAME_TOO_SHORT;
	}
}
static status_t TxCmd_CalXtalkPixel2Pixel(sci_frame_t * frame, sci_param_t param, sci_data_t data)
{
	(void) data;
	assert(frame != 0);
	status_t status = STATUS_OK;
	if (param == 0) return ERROR_SCI_INVALID_CMD_PARAMETER;
	argus_mode_t mode = (argus_mode_t) param;
	SCI_Frame_Queue08u(frame, mode);

	argus_cal_p2pxtalk_t cal = { 0 };
	status = Argus_GetCalibrationCrosstalkPixel2Pixel(myArgusPtr, mode, &cal);
	SCI_Frame_Queue08u(frame, cal.Enabled != 0);
	Serialize_Cal_P2PXtalk(frame, &cal);
	return status;
}

static status_t RxCmd_CalXtalkVectorTable(sci_frame_t * frame)
{
	if (SCI_Frame_BytesToRead(frame) > 1)
	{
		argus_mode_t mode = SCI_Frame_Dequeue08u(frame);
		if (SCI_Frame_BytesToRead(frame) > 1)
		{ /* Master sending data... */
			xtalk_t xtalk[ARGUS_DFM_FRAME_COUNT][ARGUS_PIXELS_X][ARGUS_PIXELS_Y];
			for (uint_fast8_t f = 0; f < ARGUS_DFM_FRAME_COUNT; ++f)
			{
				for (uint_fast8_t x = 0; x < ARGUS_PIXELS_X; ++x)
				{
					for (uint_fast8_t y = 0; y < ARGUS_PIXELS_Y; ++y)
					{
						xtalk[f][x][y].dS = SCI_Frame_Dequeue16s(frame);
						xtalk[f][x][y].dC = SCI_Frame_Dequeue16s(frame);
					}
				}
			}
			return Argus_SetCalibrationCrosstalkVectorTable(myArgusPtr, mode, xtalk);
		}
		else
		{ /* Master is requesting data... */
			return SCI_SendCommand(CMD_CALIBRATION_XTALK_VECTOR_TABLE, mode, 0);
		}
	}
	else
	{
		return ERROR_SCI_FRAME_TOO_SHORT;
	}
}
static status_t TxCmd_CalXtalkVectorTable(sci_frame_t * frame, sci_param_t param, sci_data_t data)
{
	(void) data;
	assert(frame != 0);
	status_t status = STATUS_OK;
	if (param == 0) return ERROR_SCI_INVALID_CMD_PARAMETER;
	argus_mode_t mode = (argus_mode_t) param;
	SCI_Frame_Queue08u(frame, mode);
	xtalk_t xtalk[ARGUS_DFM_FRAME_COUNT][ARGUS_PIXELS_X][ARGUS_PIXELS_Y];
	status = Argus_GetCalibrationCrosstalkVectorTable(myArgusPtr, mode, xtalk);
	for (uint_fast8_t f = 0; f < ARGUS_DFM_FRAME_COUNT; ++f)
	{
		for (uint_fast8_t x = 0; x < ARGUS_PIXELS_X; ++x)
		{
			for (uint_fast8_t y = 0; y < ARGUS_PIXELS_Y; ++y)
			{
				SCI_Frame_Queue16s(frame, xtalk[f][x][y].dS);
				SCI_Frame_Queue16s(frame, xtalk[f][x][y].dC);
			}
		}
	}
	return status;
}

static status_t RxCmd_CalXtalkResetVectorTable(sci_frame_t * frame)
{
	argus_mode_t mode = SCI_Frame_Dequeue08u(frame);
	return Argus_ResetCalibrationCrosstalkVectorTable(myArgusPtr, mode);
}

static status_t RxCmd_CalXtalkSeqSampleCount(sci_frame_t * frame)
{
	if (SCI_Frame_BytesToRead(frame) > 1)
	{ /* Master sending data... */
		uint16_t count = SCI_Frame_Dequeue16u(frame);
		return Argus_SetCalibrationCrosstalkSequenceSampleCount(myArgusPtr, count);
	}
	else
	{ /* Master is requesting data... */
		return SCI_SendCommand(CMD_CALIBRATION_XTALK_SAMPLE_COUNT, 0, 0);
	}
}
static status_t TxCmd_CalXtalkSeqSampleCount(sci_frame_t * frame, sci_param_t param, sci_data_t data)
{
	(void) data;
	(void) param;
	assert(frame != 0);
	status_t status = STATUS_OK;
	uint16_t count;
	status = Argus_GetCalibrationCrosstalkSequenceSampleCount(myArgusPtr, &count);
	SCI_Frame_Queue16u(frame, count);
	return status;
}

static status_t RxCmd_CalXtalkSeqMaxAmplitude(sci_frame_t * frame)
{
	if (SCI_Frame_BytesToRead(frame) > 1)
	{ /* Master sending data... */
		uq12_4_t ampl = SCI_Frame_Dequeue16u(frame);
		return Argus_SetCalibrationCrosstalkSequenceAmplitudeThreshold(myArgusPtr, ampl);
	}
	else
	{ /* Master is requesting data... */
		return SCI_SendCommand(CMD_CALIBRATION_XTALK_MAX_AMPLITUDE, 0, 0);
	}
}
static status_t TxCmd_CalXtalkSeqMaxAmplitude(sci_frame_t * frame, sci_param_t param, sci_data_t data)
{
	(void) data;
	(void) param;
	assert(frame != 0);
	status_t status = STATUS_OK;
	uq12_4_t ampl;
	status = Argus_GetCalibrationCrosstalkSequenceAmplitudeThreshold(myArgusPtr, &ampl);
	SCI_Frame_Queue16u(frame, ampl);
	return status;
}

/*******************************************************************************
 * Init Code
 ******************************************************************************/
status_t ExplorerAPI_InitCal(argus_hnd_t * argus)
{
	assert(argus != 0);
	myArgusPtr = argus;

	status_t
	status = SCI_SetCommand(CMD_CALIBRATION_GLOBAL_RANGE_OFFSET, RxCmd_CalGlobalRangeOffset, TxCmd_CalGlobalRangeOffset);
	if (status < STATUS_OK) return status;
	status = SCI_SetCommand(CMD_CALIBRATION_PIXEL_RANGE_OFFSETS, RxCmd_CalPixelRangeOffsets, TxCmd_CalPixelRangeOffsets);
	if (status < STATUS_OK) return status;
	status = SCI_SetRxCommand(CMD_CALIBRATION_PIXEL_RANGE_OFFSETS_RESET, RxCmd_CalResetPixelRangeOffsets);
	if (status < STATUS_OK) return status;
	status = SCI_SetCommand(CMD_CALIBRATION_RANGE_OFFSET_SAMPLE_COUNT, RxCmd_CalRangeOffsetSeqSampleCount, TxCmd_CalRangeOffsetSeqSampleCount);
	if (status < STATUS_OK) return status;
	status = SCI_SetCommand(CMD_CALIBRATION_XTALK_VECTOR_TABLE, RxCmd_CalXtalkVectorTable, TxCmd_CalXtalkVectorTable);
	if (status < STATUS_OK) return status;
	status = SCI_SetRxCommand(CMD_CALIBRATION_XTALK_RESET_VECTOR_TABLE, RxCmd_CalXtalkResetVectorTable);
	if (status < STATUS_OK) return status;
	status = SCI_SetCommand(CMD_CALIBRATION_XTALK_SAMPLE_COUNT, RxCmd_CalXtalkSeqSampleCount, TxCmd_CalXtalkSeqSampleCount);
	if (status < STATUS_OK) return status;
	status = SCI_SetCommand(CMD_CALIBRATION_XTALK_MAX_AMPLITUDE, RxCmd_CalXtalkSeqMaxAmplitude, TxCmd_CalXtalkSeqMaxAmplitude);
	if (status < STATUS_OK) return status;
	status = SCI_SetCommand(CMD_CALIBRATION_XTALK_PIXEL_2_PIXEL, RxCmd_CalXtalkPixel2Pixel, TxCmd_CalXtalkPixel2Pixel);
	if (status < STATUS_OK) return status;


	return status;
}


