/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer Demo Application.
 * @details		This file contains the hardware API of the Explorer Application.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef EXPLORER_API_CFG_H
#define EXPLORER_API_CFG_H

/*!***************************************************************************
 * @addtogroup 	explorerapi
 * @{
 *****************************************************************************/

#include "explorer_api.h"

/*!***************************************************************************
 * @brief	Initialize the configuration API.
 * @param	argus The API handle for API specific command execution.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t ExplorerAPI_InitCfg(argus_hnd_t * argus);

/*! @} */
#endif /* EXPLORER_API_CFG_H */
