/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer Demo Application.
 * @details		This file contains the hardware API of the Explorer Application.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef EXPLORER_API_DATA_H
#define EXPLORER_API_DATA_H

/*!***************************************************************************
 * @addtogroup 	explorerapi
 * @{
 *****************************************************************************/

#include "explorer_api.h"

/*!***************************************************************************
 * @brief	Initialize the measurement data API.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t ExplorerAPI_InitData(void);

/*! @} */
#endif /* EXPLORER_API_DATA_H */
