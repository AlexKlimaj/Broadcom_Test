/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer example application.
 * @details		This file contains hardware initialization code.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#include "explorer_hardware.h"

#include "board/clock_config.h"
#include "driver/cop.h"
#include "driver/gpio.h"
#include "driver/flash.h"
#include "driver/timer.h"
#include "driver/s2pi.h"
#include "utility/debug.h"

#if defined(CPU_MKL46Z256VLH4) || defined(CPU_MKL46Z256VLL4) || defined(CPU_MKL46Z256VMC4) || defined(CPU_MKL46Z256VMP4)
#include "driver/MKL46Z/slcd.h"
#endif

#include <assert.h>


#if defined(CPU_MKL46Z256VLH4) || defined(CPU_MKL46Z256VLL4) || defined(CPU_MKL46Z256VMC4) || defined(CPU_MKL46Z256VMP4)
#define DEFAULT_SLAVE S2PI_PINS_LOW
#else
#define DEFAULT_SLAVE S2PI_S1
#endif

#define DEFAULT_BAUD_RATE 1000000U

status_t ExplorerApp_InitHardware(void)
{
#if WATCHDOG_ENABLED
	COP_Init();
#else
	COP_Disable();
#endif

	BOARD_ClockInit();
	GPIO_Init();
#if defined(CPU_MKL46Z256VLH4) || defined(CPU_MKL46Z256VLL4) || defined(CPU_MKL46Z256VMC4) || defined(CPU_MKL46Z256VMP4)
	SLCD_Init();
	SLCD_DisplayBar();
#endif
	Timer_Init();

	/* Initialize the S2PI hardware. */
	status_t status = S2PI_Init(DEFAULT_SLAVE, DEFAULT_BAUD_RATE);
	if (status < STATUS_OK)
	{
		error_log("SPI driver 'initialization' failed, "
				  "error code: %d", status);
		return status;
	}

	status = Flash_Init();
	if (status < STATUS_OK)
	{
		error_log("Flash driver 'initialization' failed, "
				  "error code: %d", status);
		return status;
	}

	return status;
}
