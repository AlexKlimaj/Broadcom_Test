/*************************************************************************//**
 * @file
 * @brief    	SCI Handshaking Commands
 * @details		This file provides an interface for the data link layer of the
 *				systems communication interface.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef SCI_HANDSHAKING_H
#define SCI_HANDSHAKING_H
/*!***************************************************************************
 * @defgroup	sci_handshaking SCI: Handshaking
 * @ingroup		sci
 * @brief		SCI Handshaking Module
 * @details		Implements the handshaking command messages:
 * 				 - Acknowledge
 * 				 - Not-Acknowledge
 * 				 .
 * @addtogroup 	sci_handshaking
 * @{
 *****************************************************************************/

#include "sci.h"


/*!***************************************************************************
 * @brief	Sends an Acknowledge message.
 * @param	cmd The command that is acknowledged.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t SCI_SendAcknowledge(sci_cmd_t cmd);

/*!***************************************************************************
 * @brief	Sends an Not-Acknowledge message.
 * @param	cmd The command that is not-acknowledged.
 * @param	reason The reason/status that caused the not-acknowledged.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t SCI_SendNotAcknowledge(sci_cmd_t cmd, status_t reason);


/*! @} */
#endif // SCI_HANDSHAKING_H
