/*************************************************************************//**
 * @file
 * @brief    	SCI: The internal type definitions.
 * @details		This file provides an interface for the systems communication
 * 				interface.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef SCI_INTERNAL_TYPES_H
#define SCI_INTERNAL_TYPES_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

/*! Max. byte size of transmitting/receiving SCI data frames. */
#define SCI_FRAME_SIZE 		64

/*! The number of SCI data frames for Rx. */
#define SCI_FRAME_BUF_RX_CT 32

/*! The number of SCI data frames for Tx. */
#define SCI_FRAME_BUF_TX_CT	32

/*! The timeout for a tx frame request in milliseconds. */
#define SCI_TX_TIMEOUT_MSEC	1000

/*! The total number of SCI data frames. */
#define SCI_FRAME_BUF_CT (SCI_FRAME_BUF_RX_CT + SCI_FRAME_BUF_TX_CT)

/*!*****************************************************************************
 * @brief	Data buffer for outgoing frames.
 * @details	A frame needs to be initialize with an data buffer and read/write
 * 			pointers equal to zero.
 * 			Status of the frame can be determined by the following conditions:
 * 			 - Idle: WrPtr == 0 && RdPtr == 0
 * 			 - Write/Read: WrPtr != 0 (|| RdPtr == 0)
 * 			 .
 * 			The total amount of stored data is given by (size_t)(WrPtr - Buffer)
 * 			The amount that is still to read is given by (size_t)(WrPtr - RdPtr)
 *
 * 			\code
 * 			Idle:
 * 			Buffer:   0000000000000000
 * 			Write:	| (0x00)
 * 			Read:   | (0x00)
 *
 *
 * 			Write:
 * 			Buffer:   xxxxxxxx00000000
 * 			Write:	          |
 * 			Read:     | (&Buffer)
 *
 *
 * 			Read:
 * 			Buffer:   0000xxxxxxxx0000
 * 			Write:	              |
 * 			Read:         |
 *
 * 			(0 = empty; x = full)
 * 			\endcode
 *
 * 			In order to accomplish flexible frame length, the frames might link
 * 			to another frame which will be sent right after the current one has
 * 			completely sent.
 ******************************************************************************/
typedef struct SCI_Frame
{
	/*! Frame write pointer */
	uint8_t * WrPtr;

	/*! Frame read pointer */
	uint8_t * RdPtr;

	/*! Data buffer. */
	uint8_t * Buffer;

	/*! Pointer to the next frame in the chain. */
	struct SCI_Frame * Next;

} sci_frame_t;

/*! SCI frames ring buffer.*/
typedef struct
{
	/*! Command queue buffer. */
	sci_frame_t	 	*Buff;

	/*! Head of the queue. */
	sci_frame_t		*Head;

	/*! Currently used queue load. */
	volatile size_t	 Load;

	/*! Total size of the queue. */
	size_t	 		 Size;

} sci_frame_queue_t;

/*! @} */
#endif // SCI_INTERNAL_TYPES_H
