/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer Application.
 * @details		This file provides a CRC8 algorithm for the systems
 * 				communication interface.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef SCI_CRC8_H
#define SCI_CRC8_H

/*!***************************************************************************
 * @defgroup	sci_crc SCI: CRC8
 * @ingroup		sci
 * @brief		SCI CRC8 (Cyclic Redundancy Check)
 * @details		CRC8 checksum calculation with an optimized algorithm that
 * 				utilizes an look-up table and proceeds a whole byte at each step.
 * @see			http://www.sunshine2k.de/articles/coding/crc/understanding_crc.html
 * @addtogroup 	sci_crc
 * @{
 *****************************************************************************/

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/*!***************************************************************************
 * @brief	Initialization of the CRC8 module.
 * @details	Prepares the CRC8 lookup table.
 *****************************************************************************/
void SCI_CRC8_Init(void);

/*!***************************************************************************
 * @brief	Calculation routine for the CRC8 checksum.
 * @details	Uses an optimized algorithm that utilizes an look-up table with
 * 			256 entries of 8-bit values (total: 256 bytes) and
 * 			proceeds a whole byte at each step.
 * @see		http://www.sunshine2k.de/articles/coding/crc/understanding_crc.html
 * @param	crc	         The previous CRC8. If starting, pass zero.
 * @param	data		 Pointer to the send or receive array.
 * @param	length		 Number of bytes in the frame array.
 * @return	Returns the CRC8 checksum.
 *****************************************************************************/
uint8_t SCI_CRC8_Compute(uint8_t crc, const uint8_t * data, size_t length);

/*! @} */
#endif /* SCI_CRC8_H */
