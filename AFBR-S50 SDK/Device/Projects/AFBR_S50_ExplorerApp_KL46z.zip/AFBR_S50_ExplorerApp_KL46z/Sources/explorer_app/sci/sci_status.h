/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer Application.
 * @details		This file provides common (e.g. status) definitions for the
 * 				systems communication interface.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef SCI_STATUS_H
#define SCI_STATUS_H

/*!***************************************************************************
 * @addtogroup 	sci
 * @{
 *****************************************************************************/

#include "utility/status.h"

/*! @brief The SCI module specific status and error return codes.
 *  @ingroup status */
enum StatusSCI
{
	/*! Unknown/not initialized command. */
	ERROR_SCI_UNKNOWN_COMMAND = -211,

	/*! The execution of a command returned status != #STATUS_OK. */
	ERROR_SCI_CMD_EXECUTION_FAILURE = -212,

	/*! Invalid command code: e.g. is not tx/rx command. */
	ERROR_SCI_INVALID_CMD_CODE = -213,

	/*! Invalid command parameters/data/decoding failed. */
	ERROR_SCI_INVALID_CMD_PARAMETER = -214,

	/*! CRC failed -> frame invalid. */
	ERROR_SCI_CRC_FAILED = -215,

	/*! Status for buffer full. */
	ERROR_SCI_BUFFER_FULL = -216,

	/*! Received a start byte when no one has been expected. */
	ERROR_SCI_INVALID_START_BYTE = -217,

	/*! Received a stop byte when no one has been expected. */
	ERROR_SCI_INVALID_STOP_BYTE = -218,

	/*! Status for buffer full. */
	ERROR_SCI_RX_BUFFER_FULL = -219,

	/*! Received wrong escape byte. */
	ERROR_SCI_INVALID_ESCAPE_BYTE = -220,

	/*! Frame too short, i.e. too less data received for the corresponding message. */
	ERROR_SCI_FRAME_TOO_SHORT = -221,

	/*! Frame too long, i.e. too much data received for the corresponding message. */
	ERROR_SCI_FRAME_TOO_LONG = -222,

	/*! The data that was requested to be sent exceeds the maximum output data buffers size.*/
	ERROR_SCI_TX_BUFFER_EXCEEDANCE = -223,
};

/*! @} */
#endif /* SCI_STATUS_H */
