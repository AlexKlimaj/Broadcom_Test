/*************************************************************************//**
 * @file
 * @brief    	SCI Layer 2: Data Link Interface
 * @details		This file provides an interface for the data link layer of the
 *				systems communication interface.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef SCI_DATALINK_H
#define SCI_DATALINK_H

/*!***************************************************************************
 * @defgroup	sci_datalink SCI: Data Link Layer
 * @ingroup		sci
 * @brief		SCI Data Link Layer
 * @details		Implements the data link layer protocol for systems communication
 * 				interface that connects to an external device. It takes care of
 * 				sending and receiving data frames and thus byte stuffing and
 * 				CRC check.
 *
 * 				Remarks:
 * 					- Transmitting frames:
 *						- Two buffers: one for preparing data, one for sending
 *						  at the same time.
 *						- If UART Tx Line is still busy when trying to send new
 *						  data, the program is delayed until Tx is idle.
 *						.
 *					- Receiving frames:
 *  					- Special frame buffers collect data from Rx (w/o
 *  					  escape bytes)
 *  					- Only data between START and STOP is collected.
 *  					- After STOP was received, the FrameReceivedCallback
 *  					  is invoked.
 *  					.
 *
 * @addtogroup 	sci_datalink
 * @{
 *****************************************************************************/

#include "sci_status.h"
#include "sci_internal_types.h"

/*!***************************************************************************
 * @brief	Whether to allow newline (\n) in print / log messages.
 *****************************************************************************/
#define SCI_ALLOW_NEWLINE 1

/*!***************************************************************************
 * @brief	Initialize the data link module.
 * @details	Initialization implies the following steps:
 * 				- Initialization of the SCI Hardware Layer, i.e. UART/LPSCI.
 * 				- Starts to listen to incoming UART data and calls the frame
 * 				  received callback.
 * 				- Initialization of the CRC module.
 *
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t SCI_DataLink_Init(void);

/*!***************************************************************************
 * @brief	Checks the CRC checksum for a Rx frame.
 * @param	frame The Rx frame which requires CRC checking.
 * @return	Returns the \link #status_t status\endlink:
 * 			- #STATUS_OK (0) on success.
 * 			- #ERROR_SCI_CRC_FAILED if the CRC failed.
 *****************************************************************************/
status_t SCI_DataLink_CheckRxFrame(sci_frame_t * frame);

/*!***************************************************************************
 * @brief	Releases the frame queue.
 * @param	frame The frame queue to be released.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t SCI_DataLink_ReleaseFrames(sci_frame_t * frame);

/*!***************************************************************************
 * @brief	Trigger the data transfer and releases the Tx buffers.
 * @details	Before the frame is transfered, a stop byte is added to the end
 * 			of the data buffer.
 * @param	frame The frame to be sent.
 * @return	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t SCI_DataLink_SendTxFrame(sci_frame_t * frame);

/*!***************************************************************************
 * @brief	Find an unused Tx buffer from the queue and prepare it with a start
 * 			byte.
 * @details	If sending data over the SCI, an new and empty Tx frame needs to be
 * 			claimed for usage of the command. This functions finds one and
 * 			prepares it with an start byte. A pointer to the frame is returned
 * 			if one is found. Otherwise null, so checking for null pointer is
 * 			recommended!
 * @param	queueStartByte Whether to queue a start byte into the buffer.
 * @return	Returns a pointer to an free Tx frame, zero if no one is currently
 * 			available.
 *****************************************************************************/
sci_frame_t * SCI_DataLink_RequestTxFrame(bool queueStartByte);

/*! @} */
#endif /* SCI_DATALINK_H */
