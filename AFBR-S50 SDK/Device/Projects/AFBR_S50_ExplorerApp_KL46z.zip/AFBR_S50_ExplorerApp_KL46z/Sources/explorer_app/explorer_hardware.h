/*************************************************************************//**
 * @file
 * @brief    	This file is part of the AFBR-S50 Explorer example application.
 * @details		This file contains hardware initialization code.
 * 
 * @copyright	Copyright c 2016-2019, Avago Technologies GmbH.
 * 				All rights reserved.
 *****************************************************************************/

#ifndef EXPLORER_HARDWARE_H
#define EXPLORER_HARDWARE_H

/*!***************************************************************************
 * @defgroup	hwinit Hardware Initialization Module
 * @ingroup		explorerapp
 * @brief		Hardware Initialization Module
 * @details		Functions to initialize all the required hardware.
 * @addtogroup 	hwinit
 * @{
 *****************************************************************************/

#include "explorer_app.h"



/*!***************************************************************************
 * @brief	Initialization of hardware drivers.
 * @details	Initializes all the hardware of the given board.
 * 			- Watchdog timer
 * 			- Clocks
 * 			- GPIO
 * 			- LCD
 * 			- Timers
 * 			- SPI
 * 			- Flash
 * 			.
 *
 * @return 	Returns the \link #status_t status\endlink (#STATUS_OK on success).
 *****************************************************************************/
status_t ExplorerApp_InitHardware(void);



/*! @} */
#endif /* EXPLORER_HARDWARE_H */
